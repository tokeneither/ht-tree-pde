#!/usr/bin/env python3
"""Exact arithmetic checks for the joint-gap witness added to the manuscript.

This checks the finite witness and attaining allocation. The proof of global
optimality and of the true rank-one gain is in sections/proofs.tex.
No scientific Python dependencies or random optimization are required.
"""
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path


INDICES = tuple(product(range(2), repeat=3))


def row_gram(tensor, axis):
    rest = [j for j in range(3) if j != axis]
    rows = []
    for i in range(2):
        row = []
        for pair in product(range(2), repeat=2):
            index = [0, 0, 0]
            index[axis] = i
            for j, value in zip(rest, pair):
                index[j] = value
            row.append(tensor.get(tuple(index), Q(0)))
        rows.append(row)
    return [[sum(a * b for a, b in zip(x, y)) for y in rows] for x in rows]


def verify_all_edge_obstruction():
    """Sparse integer/Fraction checks of all three MM-tensor witnesses."""
    checked = []
    for n in range(1, 6):
        support = [((i,j),(j,k),(k,i))
                   for i,j,k in product(range(n),repeat=3)]
        assert len(set(support)) == n**3
        for axis in range(3):
            rows = {}
            for index in support:
                column = tuple(index[j] for j in range(3) if j != axis)
                rows.setdefault(index[axis],set()).add(column)
            assert len(rows) == n*n
            values = list(rows.values())
            assert all(len(row) == n for row in values)
            assert all(not values[i].intersection(values[j])
                       for i in range(len(values)) for j in range(i))
            # Singular values are all sqrt(n), so no irrational arithmetic
            # is needed for the SQUARED nuclear norm of W=F/n².
            witness_nuclear_squared = Q(len(rows)**2*n,n**4)
            assert witness_nuclear_squared == n
        pairing = Q(len(support),n*n)
        assert 2*pairing-witness_nuclear_squared == n
        checked.append(dict(n=n,true_rank_one_gain=1,
                            optimized_all_edge_bound=n,witness='F/n^2'))
    return checked


def main():
    forcing = {(1, 0, 0): Q(1), (0, 1, 0): Q(1), (0, 0, 1): Q(1)}
    witness = {(1, 0, 0): Q(15, 32), (0, 1, 0): Q(15, 32),
               (0, 0, 1): Q(20, 32)}
    allocation = {(1, 0, 0): Q(1, 8), (0, 1, 0): -Q(1, 8)}
    pairing = sum(forcing.get(i, 0) * witness.get(i, 0) for i in INDICES)
    assert pairing == Q(25, 16)
    nuclear_squared = (Q(15, 32) + Q(25, 32)) ** 2
    assert nuclear_squared == Q(25, 16)
    attained = Q(0)
    for axis, sign in ((0, 1), (1, -1)):
        gram = row_gram(witness, axis)
        assert gram[0][1] == gram[1][0] == 0
        assert sorted([gram[0][0], gram[1][1]]) == [Q(15, 32)**2, Q(25, 32)**2]
        allocated = {i: forcing.get(i, Q(0)) / 2 + sign * allocation.get(i, Q(0))
                     for i in INDICES}
        gram_allocated = row_gram(allocated, axis)
        assert gram_allocated == [[Q(25, 64), 0], [0, Q(25, 64)]]
        attained += 2 * gram_allocated[0][0]
    # Identical nuclear norms make the Fenchel bound independent of alpha.
    dual_witness_value = 2 * pairing - nuclear_squared
    assert attained == dual_witness_value == Q(25, 16)
    assert Q(4, 3) < attained < 2
    result = {
        "arithmetic": "exact rational",
        "checked_cuts": [0, 1],
        "witness_pairing": str(pairing),
        "witness_nuclear_norm_squared_per_cut": str(nuclear_squared),
        "attaining_allocation_value": str(attained),
        "fenchel_lower_bound_all_allocations_all_splits": str(dual_witness_value),
        "optimized_two_cut_value_over_proved_rank_one_gain": str(attained / Q(4, 3)),
        "status": "passed",
        "all_edge_scalar_allocation": verify_all_edge_obstruction(),
        "scope": "Finite witness check; see manuscript for the complete analytical proof."
    }
    output = Path(__file__).resolve().parent / "generated" / "example_checks.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print("Exact joint-gap witness: passed (optimized bound 25/16; true gain 4/3).")
    print("All-edge allocation witnesses: passed for n=1,...,5 (bound n; true gain 1).")


if __name__ == "__main__":
    main()
