#!/usr/bin/env bash
set -euo pipefail
paper_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
project_root="$(cd -- "$paper_root/.." && pwd)"
cd -- "$paper_root"
mkdir -p build
python_bin="${PYTHON:-python3}"
if [[ -f "$project_root/results/v2_fast/all_results.json" ]]; then
  "$python_bin" -B generate_tables.py
  if [[ -f "$project_root/results/parametric_reuse_n12/all_results.json" ]]; then
    "$python_bin" -B "$project_root/scripts/report_certificate_reuse.py"
  fi
else
  for table_file in four_dimensional_table hierarchical_table compressed_input_table compression_gap_table excess_energy_table sharp_gap_table parametric_time_table parametric_coverage_table; do
    if [[ ! -f "generated/$table_file.tex" ]]; then
      printf 'Missing generated/%s.tex; restore the bundled tables or full research repository.\n' "$table_file" >&2
      exit 1
    fi
  done
  printf 'Using bundled tables; raw benchmark data are not present in this source-only copy.\n'
fi
"$python_bin" -B verify_examples.py
pdf_engine="${PDFLATEX_BIN:-}"
bib_engine="${BIBTEX_BIN:-}"
if [[ -z "$pdf_engine" && -L "$project_root/.cache/paper-tools/texlive-bin" ]]; then
  texlive_bin="$(readlink -f "$project_root/.cache/paper-tools/texlive-bin")"
  pdf_engine="$texlive_bin/pdflatex"
  bib_engine="$texlive_bin/bibtex"
elif [[ -z "$pdf_engine" ]] && command -v pdflatex >/dev/null 2>&1; then
  pdf_engine="$(command -v pdflatex)"
  bib_engine="$(command -v bibtex)"
fi
if [[ -n "$pdf_engine" ]]; then
  if [[ -z "$bib_engine" ]]; then
    bib_engine="$(dirname -- "$pdf_engine")/bibtex"
  fi
  export TEXMFVAR="$project_root/.cache/paper-texlive-var"
  export TEXMFCONFIG="$project_root/.cache/paper-texlive-config"
  "$pdf_engine" -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
  "$bib_engine" build/main
  "$pdf_engine" -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
  "$pdf_engine" -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
  cp build/main.pdf draft.pdf
  printf 'Built: %s/draft.pdf\n' "$paper_root"
  exit 0
fi
if [[ -n "${TECTONIC:-}" ]]; then
  tex_engine="$TECTONIC"
elif [[ -x "$project_root/.cache/paper-tools/tectonic" ]]; then
  tex_engine="$project_root/.cache/paper-tools/tectonic"
elif command -v tectonic >/dev/null 2>&1; then
  tex_engine="$(command -v tectonic)"
else
  tex_engine=""
fi
if [[ -n "$tex_engine" ]]; then
  XDG_CACHE_HOME="$project_root/.cache/paper-tex" "$tex_engine" \
    --keep-logs --keep-intermediates --outdir build main.tex
elif command -v latexmk >/dev/null 2>&1; then
  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex
else
  printf 'Install Tectonic or TeX Live with latexmk, then rerun this script.\n' >&2
  exit 1
fi
cp build/main.pdf draft.pdf
printf 'Built: %s/draft.pdf\n' "$paper_root"
