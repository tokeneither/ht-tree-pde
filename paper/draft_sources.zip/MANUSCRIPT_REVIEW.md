# Internal mathematical and evidence review

Reviewed on 2026-09-20 by a collaborating assistant. This is an internal
cross-check, not external peer review or a guarantee of literature priority.
The review covered the main file, all manuscript sections, generated tables,
the relevant implementation, and the recorded experimental outputs.

## Mathematical checks

- **Energy cancellation:** expanding the SPD energy gives the displayed
  common constant minus the attained quadratic gain. Comparing a feasible
  lower gain against all competing upper gains identifies the globally best
  *family* in the prescribed collection; it does not assert global optimality
  of the fitted tensor. The manuscript consistently makes this distinction.
- **Centered bound:** dropping the nonnegative remainder square is valid
  for a PSD remainder, even if singular. Left–right SPD whitening preserves
  matrix rank; arbitrary operator whitening would not. The truncated-SVD
  supremum and convexity in the center follow as stated.
- **Metric dominance:** expanding the displacement representation recovers
  the centered spectral expression. Loewner order strengthens the displacement
  penalty pointwise, and the inequality survives center minimization. The
  shifted geometric factors have eigenvalues at least half the common lower
  bound and satisfy the scalar arithmetic–geometric mean inequality.
- **Optimized scalar gap:** projecting centers onto the forcing block and
  averaging signed permutations are valid convexity arguments. Minimizing
  the remaining scalar quadratic gives the stated exact denominator. The
  Dirichlet extension's band cardinality, eigenvalue bounds, random rank-r
  subset argument, and final ratio were checked algebraically. These are
  comparisons of relaxations, not runtime lower bounds.
- **Spectral tail:** product projection preserves every matricization-rank
  cap; commutation eliminates cross energy. No rank assumption on the omitted
  component is used. The full-space gain for retained forcing is consequently
  the reduced gain, and the additive tail-energy enclosure is valid.
- **Independent-edge obstruction:** the matrix-multiplication tensor has
  rank-one tensor gain one and each singleton's largest squared singular
  value n. The three-mode HT constraints reduce to complete separability.
  This proves the unbounded independent-edge gap claimed.
- **Joint allocation:** the two split objectives sum to the original
  objective; relaxing each to its own rank family therefore gives a valid
  sum bound for every allocation. Convexity and the stated gradient or
  subgradient follow from the supremum of affine forcing functionals.
- **Sharper joint-gap check:** the initial explicit allocation alone
  demonstrated a suboptimal bound, not a gap after exact dual optimization.
  The additional witness supplied during review resolves that issue. For
  `Z_100 = Z_010 = 15/32` and `Z_001 = 20/32`, both selected unfoldings have
  orthogonal rows with norms `15/32` and `25/32`, hence nuclear norm `5/4`.
  Also `<F,Z> = 25/16`. Dual Hölder/Fenchel gives
  `||F_i||_op^2/alpha_i >= 2<F_i,Z> - alpha_i ||Z^[i]||_*^2`.
  Summing establishes `J(D) >= 25/16` for every allocation and every
  `0 < alpha < 1`. The explicit allocation attains that value. Thus the
  optimized two-cut bound is exactly `25/16 > 4/3`; including this witness
  justifies the stronger incompleteness statement.

## Evidence and implementation checks

- The relevant HT data are `results/v3_early`, not the historical late
  schedule in `results/v3`. All 14 non-tie cases certify with one feasible
  fit and zero Richardson updates; the exact tie abstains.
- All 45 recorded HT calls were independently checked to have 315 lower
  and upper entries. Every successful call satisfies the stated strict
  separation condition including its numerical guard over all competitors.
- The proposed HT initialization is the inverse of a modewise product
  minorant applied to the forcing. It is not the full Kronecker-sum inverse;
  claiming zero full-solution formation is consistent with the implementation.
- The 4D abstract family has unrestricted singleton ranks. The experiments
  explicitly distinguish this single-matricization setting from all-edge HT.
- The stated 4D counts and median/aggregate timing ratios match
  `results/v2_fast`. The manuscript retains the sensitivity slowdown and
  separates 19/20 non-tie successes from the exact-tie control.
- The compressed-input counts and timings match supplied eleven-term
  spectral CP data; input-factor discovery is excluded explicitly. The
  largest forcing-factor count is `44 * 4096 + 11 = 180235`; eigenvalues
  are counted separately.
- The shared-subtree HT baseline remains faster in every non-tie case.
  The manuscript does not turn a smaller number of primal fits into an
  unsupported timing or state-of-the-art claim.
- A citation/label scan found no undefined equation references, duplicate
  labels, or missing BibTeX keys.

## Concrete corrections identified during review

1. The author field originally used a display-math opener instead of a line
   break. The root author replaced it with a single-line author placeholder.
2. HT table extraction originally used internal `elapsed` while the benchmark
   design records full returned-call time as `wall_seconds`. It now uses
   `wall_seconds` and checks agreement with the recorded report summary.
3. ALS stage budgets `0,2,6` and `0,2,6,16` are successive per-stage caps,
   not cumulative budgets: every warm-started solve receives its listed
   `max_sweeps`. Richardson counts `0,2,5,10` are genuinely cumulative.
   This wording correction was sent to the manuscript author.
4. For nonuniform allocated ranks, canonicalizing complementary root cuts
   should assign the minimum of the corresponding node caps to the canonical
   edge rank. This does not change uniform-rank experiments, but removes a
   notation ambiguity in the general setting.
5. The optimized joint-gap witness above was independently checked and sent
   for inclusion in the proof, resolving the original overinterpretation of
   one particular allocation.

## Remaining scope limits

The mathematical results are exact-arithmetic results for discrete SPD
operators. Ordinary floating-point margins and rank diagnostics are not
interval proofs. Numerical checks do not establish global convergence of
ALS, correctness for arbitrary tree collections never evaluated, scalability
of the dense retained HT implementation, application-level gains, or novelty
relative to all existing operator-weighted tensor relaxations. The manuscript
states these restrictions. No additional substantive mathematical blocker
was found in this review once the concrete corrections above are incorporated.

## Extension review, 20 September 2026

The extended manuscript adds the compression-resistant comparison (Theorem
5.4), the all-edge scalar-allocation obstruction (Proposition 5.7), and the
actual-tensor excess-error guarantee (Proposition 4.1). Complete proofs of
the compression theorem and its reductions are in Appendix A.9--A.11.
The previous review above remains a record of the original draft.

The new scalar minimax argument explicitly handles zero coordinates of
`A-mI`; the compression comparison includes every commuting orthogonal
product projector and an exact full-energy tail. An independent internal
proof check corrected a factor of two in an intermediate denominator;
the final constants remain `k^(2/3)/4` and `3 k^(2/3)`. The comparison
excludes rank-aware tails and multiband allocations. The all-edge claim
is limited to scalar operator splits; the known spectral norm of the
matrix-multiplication tensor is now cited explicitly.

Validation: 131 implementation tests pass; independent scalar primal/dual
values agree to `4.55e-13`; exhaustive subsets for k<=10 agree with the
suffix reduction; 22 old/current default-policy cases agree exactly in
decisions, full intervals and work counts. Integer/rational witness checks
cover the all-edge obstruction for n=1,...,5. The new tie controls check the
returned tensor against exact SVD energy oracles. Neither these experiments
nor the original timings establish a general runtime advantage. The
epsilon decision retains the manuscript's floating-point, non-interval scope.

These are internal checks and not external peer review or an exhaustive
bibliographic priority audit. The current technical build record is in
`validation.json`.
