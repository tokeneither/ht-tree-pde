# Bibliography audit

Checked on 2026-09-20. The bibliography uses publisher pages, author-hosted
papers, and arXiv records. This audit establishes the listed metadata and
the stated relationship to the draft; it is not an exhaustive novelty search.
No acceptance decision is inferred from an arXiv identifier or a DOI.

The many-query extension adds five primary records, inspected in the
[targeted novelty audit](../docs/PRIOR_ART_REUSE_AUDIT.md):

| Added key | Primary source | Role |
|---|---|---|
| `andersson2017` | [Publisher](https://link.springer.com/article/10.1007/s11590-017-1146-5) | Andersson, Carlsson and Olsson, *Convex envelopes for fixed rank approximation*, Optimization Letters 11, 1783–1795; existing convex-envelope machinery. |
| `carlsson2019` | [Author preprint](https://arxiv.org/abs/1811.03439) | *On Convex Envelopes and Regularization of Non-convex Functionals Without Moving Global Minima*, JOTA 183, 66–84; Theorem 5.1, retained positive quadratic remainder. |
| `derksen2013` | [Inspected version 2](https://arxiv.org/abs/1308.3860v2) | Known tensor nuclear/injective norms, including matrix multiplication; explicit inspected preprint citation. |
| `ndiaye2017` | [JMLR](https://jmlr.org/papers/v18/16-577.html) | Gap Safe screening, 18(128), 1–33; methodological context, not the same parameter-space certificate. |
| `rozza2019` | [Inspected chapter preprint](https://arxiv.org/abs/1911.08954v1) | Rozza, Hess, Stabile, Tezzele and Ballarin; established offline–online parametric PDE reduction. |

The optimized centered certificate is now explicitly described as known
low-rank convexification after product whitening. The support-function
transport and affine solution superposition are also attributed as existing
mathematical mechanisms. The sharper quantitative compression comparison
is a candidate contribution, not an established priority claim.

| BibTeX key | Primary verification | Checked metadata / use |
|---|---|---|
| `grasedyck2010` | [SIAM](https://epubs.siam.org/doi/10.1137/090764189), [author publication list](https://www.igpm.rwth-aachen.de/team/grasedyck/publications/ta) | Lars Grasedyck; SIMAX 31(4), 2029–2054 (2010); hierarchical SVD and fixed-tree approximation. |
| `ballani2014` | [SIAM](https://epubs.siam.org/doi/10.1137/130926328), [author preprint](https://www.igpm.rwth-aachen.de/Download/reports/pdf/IGPM367.pdf) | Jonas Ballani and Lars Grasedyck; SISC 36(4), A1415–A1431 (2014). The preprint dates from 2013. |
| `bachmayr2023` | [Cambridge](https://www.cambridge.org/core/journals/acta-numerica/article/lowrank-tensor-methods-for-partial-differential-equations/06D2B93A3E4FB412CB13F8B107F399AB) | Markus Bachmayr; Acta Numerica 32, 1–121 (2023); DOI 10.1017/S0962492922000125. |
| `vandereycken2010` | [author-hosted published paper](https://www.unige.ch/math/vandereycken/papers/published_VandereyckenV_2010.pdf) | Bart Vandereycken and Stefan Vandewalle; SIMAX 31(5), 2553–2579 (2010); DOI 10.1137/090764566. Section 3, especially the energy identity on printed page 2557, is a direct precedent for cancellation of the unknown energy constant. |
| `grussler2018` | [arXiv record](https://arxiv.org/abs/1612.03186) | Christian Grussler and Pontus Giselsson; SIAM J. Optim. 28(4), 3057–3078 (2018); DOI 10.1137/17M1115770. The preprint first appeared in 2016. |
| `tomioka2013` | [official NeurIPS proceedings](https://proceedings.neurips.cc/paper/2013/hash/109a0ca3bc27f3e96597370d5c8cf03d-Abstract.html), [paper](https://proceedings.neurips.cc/paper/2013/file/109a0ca3bc27f3e96597370d5c8cf03d-Paper.pdf) | Ryota Tomioka and Taiji Suzuki; NeurIPS volume 26 (2013). Pages omitted rather than inferred. Section 2 gives overlapped/latent norm duality. This is conceptual prior art for allocation, not a claim that the paper contains our PDE formula. |
| `dolgov2014` | [arXiv record](https://arxiv.org/abs/1304.1222) | Sergey V. Dolgov and Dmitry V. Savostyanov; SISC 36(5), A2248–A2271 (2014); DOI 10.1137/140953289. Part II, not Part I, is cited. |
| `beckermann2013` | [SIAM](https://epubs.siam.org/doi/10.1137/120900204) | Bernhard Beckermann, Daniel Kressner, Christine Tobler; SINUM 51(6), 3307–3326 (2013); DOI 10.1137/120900204. |
| `falco2011` | [publisher](https://www.sciencedirect.com/science/article/pii/S0022247X10009996), [Anthony Nouy's publication list](https://anthony-nouy.github.io/publications.html) | Antonio Falcó and Anthony Nouy; JMAA 376(2), 469–480 (2011); DOI 10.1016/j.jmaa.2010.12.003. |
| `guo2025cadet` | [arXiv version 5](https://arxiv.org/abs/2502.02711v5) | Author order Guo, Deshpande, Kiedrowski, Wang, Gorodetsky. First posted 2025; inspected revision July 7, 2026. Title changed from earlier versions; current title retained. Explicit preprint citation. |
| `guo2026hist` | [arXiv version 2](https://arxiv.org/abs/2603.27856v2) | Author order Guo, Deshpande, Wang, Kiedrowski, Gorodetsky. First posted March 29, 2026; revision July 28, 2026. Explicit inspected-preprint citation. |
| `hikihara2023` | [arXiv record](https://arxiv.org/abs/2209.03196) | Toshiya Hikihara, Hiroshi Ueda, Kouichi Okunishi, Kenji Harada, Tomotoshi Nishino; Physical Review Research 5, 013031 (2023); DOI 10.1103/PhysRevResearch.5.013031. |
| `grelier2018` | [arXiv version 2](https://arxiv.org/abs/1811.04455v2), [author's publication list](https://anthony-nouy.github.io/publications.html) | Erwan Grelier, Anthony Nouy, Mathilde Chevreuil; first submitted November 2018, revised January 2019. The author list still classifies this title as a preprint; no journal venue inserted. |
| `ali2020` | [arXiv record](https://arxiv.org/abs/1809.11001) | Mazen Ali and Anthony Nouy; Z. Anal. Anwend. 39(3), 349–369 (2020); DOI 10.4171/ZAA/1663. |

## Corrections and remaining distinctions

Extension check: [Friedland, Lim and Zhang (2019)](https://www.stat.uchicago.edu/~lekheng/work/grothendieck.pdf),
*Grothendieck constant is norm of Strassen matrix multiplication tensor*,
Numerische Mathematik 143, 905–922, DOI 10.1007/s00211-019-01070-6, is now
`friedland2019`. Equation (23) explicitly gives the unit tensor spectral
norm used in the obstruction example. The draft attributes that fact and
derives the all-edge scalar-allocation witness from the unfolding spectra.
The compression-resistant comparison and this allocation consequence are
new to the draft; this audit does not establish priority for either result.

- **Tree Adaptive Approximation (2014) is by Ballani and Grasedyck.**
  It must not be attributed to Kressner and Tobler, whose other tensor
  algorithms are relevant but constitute different papers.
- The HiST arXiv record lists a related DOI,
  [10.1016/j.jcp.2026.115230](https://doi.org/10.1016/j.jcp.2026.115230).
  The publisher resolver could not be read in this audit. The draft therefore
  cites the precise preprint version inspected, and makes no assertion about
  its acceptance date, issue, or journal pagination.
- Cadet's present title is *Tensor Network Structure Search Via Canonical
  Dimension Tree Enumeration*. Earlier versions had a different title.
- The low-rank inducing norm article is a **2018 published paper**, not merely
  an unpublished 2016 preprint.
- The common quadratic energy identity, tensor tree discovery, cached cut
  spectra, convex spectral relaxations, and allocation duality are existing
  ideas. The draft identifies the narrower structured-metric comparison and
  quantitative screening results instead of assigning priority to these tools.
- This bibliography does not establish absence of a previous identical
  balanced-geometric comparison theorem. A specialist novelty review remains
  necessary before a submission-level originality claim.
